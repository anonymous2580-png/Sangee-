# Sangee Project

This is the AI-based Sangee project.