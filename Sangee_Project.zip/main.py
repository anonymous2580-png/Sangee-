# Main application code for Sangee

print("Welcome to Sangee AI!")